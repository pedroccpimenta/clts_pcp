from setuptools import setup

setup(
    name='lts',
    version='1.0.0',
    packages=['lts.py'],
    install_requires=[       "time"    ],
)